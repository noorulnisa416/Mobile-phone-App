<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: home.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mobile Phone Repository - Login</title>
  <style>
    body { font-family: Arial; background: #f0f4f8; display: flex;
           justify-content: center; align-items: center; height: 100vh; }
    .login-box { background: white; padding: 40px; border-radius: 8px;
                 box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 350px; }
    h2 { text-align: center; color: #1F3864; }
    input { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ccc;
            border-radius: 4px; box-sizing: border-box; }
    button { width: 100%; padding: 12px; background: #2E75B6; color: white;
             border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
    button:hover { background: #1F3864; }
    .error { color: red; text-align: center; font-size: 14px; }
  </style>
</head>
<body>
  <div class="login-box">
    <h2>Mobile Phone Repository</h2>
    <form method="POST" action="login.php">
      <label>Username:</label>
      <input type="text" name="username" required placeholder="Enter username">
      <label>Password:</label>
      <input type="password" name="password" required placeholder="Enter password">
      <button type="submit">Login</button>
      <?php if(isset($error)) echo "<p class='error'>".htmlspecialchars($error)."</p>"; ?>
    </form>
  </div>
</body>
</html>
