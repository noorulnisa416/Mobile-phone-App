<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: index.php"); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Home - Mobile Phone Repository</title>
  <style>
    body{font-family:Arial;background:#f7f9fc;padding:20px}
    .nav{margin-bottom:20px}
    .nav a{margin-right:12px;padding:8px 12px;background:#2E75B6;color:#fff;text-decoration:none;border-radius:4px}
    .welcome{margin-bottom:12px}
  </style>
</head>
<body>
  <div class="welcome">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION["user"]); ?></h2>
    <p>Use the links below to manage mobile phone records.</p>
  </div>
  <div class="nav">
    <a href="add_phone.php">Add Phone</a>
    <a href="retrieve_all.php">View All Records</a>
    <a href="price_10k_20k.php">Price 10k-20k</a>
    <a href="price_above_20k.php">Price &gt; 20k</a>
    <a href="logout.php">Logout</a>
  </div>
</body>
</html>
