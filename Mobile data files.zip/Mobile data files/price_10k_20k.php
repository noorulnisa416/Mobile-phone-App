<?php
// price_10k_20k.php - Records with price between 10,000 and 20,000
session_start();
if (!isset($_SESSION["user"])) { header("Location: index.php"); exit(); }
require_once "db_connect.php";

try {
    $stmt = $conn->prepare(
        "SELECT * FROM mobile_phones WHERE price > 10000 AND price < 20000");
    if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h3>Phones Priced Between PKR 10,000 and PKR 20,000</h3>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>Name</th><th>Brand</th><th>Model</th><th>Price</th></tr>";

    if ($result->num_rows === 0) {
        echo "<tr><td colspan='5'>No records found.</td></tr>";
    } else {
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>".htmlspecialchars($row["id"])."</td><td>".htmlspecialchars($row["name"])."</td>",
                 "<td>".htmlspecialchars($row["brand"])."</td><td>".htmlspecialchars($row["model"])."</td>",
                 "<td>PKR ".htmlspecialchars($row["price"])."</td></tr>";
        }
    }
    echo "</table>";
    echo "<p><a href='home.php'>Back to Home</a></p>";

} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
