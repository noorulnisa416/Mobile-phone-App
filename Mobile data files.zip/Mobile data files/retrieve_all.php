<?php
// retrieve_all.php - Fetch and display all mobile phone records
session_start();
if (!isset($_SESSION["user"])) { header("Location: index.php"); exit(); }
require_once "db_connect.php";

try {
    $result = $conn->query("SELECT * FROM mobile_phones ORDER BY id ASC");

    if ($result === false) {
        throw new Exception("Query failed: " . $conn->error);
    }

    echo "<h3>All Mobile Phone Records</h3>";
    echo "<table border='1' cellpadding='8' cellspacing='0'>";
    echo "<tr><th>ID</th><th>Name</th><th>Brand</th><th>Model</th><th>Price</th></tr>";

    if ($result->num_rows === 0) {
        echo "<tr><td colspan='5'>No records found.</td></tr>";
    } else {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>",
                 "<td>".htmlspecialchars($row["id"])."</td>",
                 "<td>".htmlspecialchars($row["name"])."</td>",
                 "<td>".htmlspecialchars($row["brand"])."</td>",
                 "<td>".htmlspecialchars($row["model"])."</td>",
                 "<td>PKR ".htmlspecialchars($row["price"])."</td>",
                 "</tr>";
        }
    }
    echo "</table>";
    echo "<p><a href='home.php'>Back to Home</a></p>";
} catch (Exception $e) {
    echo "<p style='color:red'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
