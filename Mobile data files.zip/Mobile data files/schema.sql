-- =============================================
-- DATABASE: mobile_repo
-- =============================================
CREATE DATABASE IF NOT EXISTS mobile_repo;
USE mobile_repo;

-- Table 1: Users (Login credentials)
CREATE TABLE IF NOT EXISTS users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

-- Insert default admin user
INSERT INTO users (username, password) VALUES ("admin", "admin123");

-- Table 2: Mobile Phones (Repository data)
CREATE TABLE IF NOT EXISTS mobile_phones (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    name   VARCHAR(100) NOT NULL,
    brand  VARCHAR(50) NOT NULL,
    model  VARCHAR(50) NOT NULL,
    price  DECIMAL(10, 2) NOT NULL
);

-- Sample records for testing
INSERT INTO mobile_phones (name, brand, model, price) VALUES
    ("Vivo Y02", "Vivo", "Y02", 14500),
    ("Redmi Note 12", "Xiaomi", "Note 12", 35999),
    ("Tecno Spark 10", "Tecno", "Spark 10", 18000),
    ("Samsung Galaxy A14", "Samsung", "A14", 28000),
    ("Infinix Hot 30", "Infinix", "Hot 30", 12500);
