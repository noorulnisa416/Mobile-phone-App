<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: index.php"); exit(); }
require_once "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $name  = trim($_POST["name"]);
        $brand = trim($_POST["brand"]);
        $model = trim($_POST["model"]);
        $price = (float)$_POST["price"];

        // Logical validation
        if (empty($name) || empty($brand) || empty($model)) {
            throw new Exception("All fields are required.");
        }
        if ($price <= 0) {
            throw new Exception("Price must be a positive number.");
        }

        $stmt = $conn->prepare(
            "INSERT INTO mobile_phones (name, brand, model, price) VALUES (?, ?, ?, ?)");
        if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
        $stmt->bind_param("sssd", $name, $brand, $model, $price);

        if ($stmt->execute()) {
            echo "<p style='color:green'>Phone record added successfully!</p>";
            echo "<p><a href='add_phone.php'>Add another</a> | <a href='retrieve_all.php'>View all</a></p>";
        } else {
            throw new Exception("Insert failed: " . $stmt->error);
        }
    } catch (Exception $e) {
        echo "<p style='color:red'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<p><a href='add_phone.php'>Back</a></p>";
    }
} else {
    header('Location: add_phone.php');
    exit();
}
?>
