# Mobile Phone Repository - Prototype

Simple PHP + MySQL prototype to add and view mobile phone records.

Setup
- Install WAMP/XAMPP and start Apache + MySQL
- Place files in htdocs/mobile_repo/ (or equivalent)
- Import `schema.sql` using phpMyAdmin or MySQL CLI
- Open `http://localhost/mobile_repo/index.php`

Default credentials
- Username: `admin`
- Password: `admin123`

Files
- `db_connect.php` : DB connection
- `index.php` : Login page
- `login.php` : Login processing
- `home.php` : Dashboard/navigation
- `add_phone.php` / `insert_phone.php` : Create phone records
- `retrieve_all.php` : Show all records
- `price_10k_20k.php` : Filtered view (10k-20k)
- `price_above_20k.php` : Filtered view (>20k)
- `logout.php` : Logout
- `schema.sql` : Database schema + sample data

Notes
- This is a simple prototype: passwords are stored plaintext for demonstration only. For production, use password hashing and stronger authentication.
