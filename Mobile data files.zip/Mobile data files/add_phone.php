<?php
session_start();
if (!isset($_SESSION["user"])) { header("Location: index.php"); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Mobile Phone</title>
  <style>body{font-family:Arial;padding:20px}label{display:block;margin-top:8px}input,button{padding:8px;margin-top:4px;width:300px}</style>
</head>
<body>
  <h3>Add New Mobile Phone</h3>
  <form method="POST" action="insert_phone.php">
    <label>Phone Name:</label>
    <input type="text" name="name" required placeholder="e.g. Samsung Galaxy S24">
    <label>Brand:</label>
    <input type="text" name="brand" required placeholder="e.g. Samsung">
    <label>Model:</label>
    <input type="text" name="model" required placeholder="e.g. S24 Ultra">
    <label>Price (PKR):</label>
    <input type="number" name="price" required min="0" placeholder="e.g. 85000">
    <br>
    <button type="submit">Add Phone</button>
  </form>
  <p><a href="home.php">Back to Home</a></p>
</body>
</html>
